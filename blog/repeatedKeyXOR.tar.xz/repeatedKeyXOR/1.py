from encrypted import enc_numbers

def shift(data, offset):
    return data[offset:] + data[:offset]

def count_same(a, b):
    count = 0
    for x, y in zip(a, b):
        if x == y:
            count += 1
    return count

print ('key lengths')
for key_len in range(1, 90): # try multiple key lengths
    freq = count_same(enc_numbers, shift(enc_numbers, key_len))

    print ('{0:< 3d} | {1:3d} |'.format(key_len, freq) + '=' * (freq / 4))
